import React from 'react'


import styles from "./footer.module.css";

const Footer = () => {
  return (
    <><footer className="footer_area">
    <div className="footer_widget_area">
        <div className="container">
            <div className="row">
                <div className="col-md-4 col-xs-6">
                    <aside className="f_widget about_widget">
                        <img src="https://stssevastorage.blob.core.windows.net/myorlandostay/mylogo.png" alt="MyOrlando Stay Logo"/>
                        <div className="ab_wd_list">
                            <div className="media">
                                <div className="media-left">
                                    <i className="fa fa-map-marker"></i>
                                </div>
                                <div className="media_body">
                                    <h4>
                                        2655 Andros Lane (Central Location only)
                                        <br/>Celebration
                                        Orlando
                                        FL 34747
                                        United States of America
                                    </h4>
                                </div>
                            </div>
                            <div className="media">
                                <div className="media_left">
                                    <i className="fa fa-phone"></i>
                                </div>
                                <div className="media_body">
                                    <h4>+1(407) 557-8999</h4>
                                </div>
                            </div>
                            <div className="media">
                                <div className="media_left">
                                    <i className="fa fa-whatsapp"></i>
                                </div>
                                <div className="media_body">
                                   
                                    <a href="#" >+91-9839048100</a>
                                </div>

                            </div>
                        </div>

                    </aside>
                </div>
                <div className="col-md-3 col-xs-6">
                    <aside className="f_widget link_widget" >
                        <div className="f_title">
                            <h3>Quick Links</h3>
                        </div>
                        <ul>
                            <li><a href="/Home/Index"> Home</a></li>
                            <li><a href="/Home/AboutUs">About Us</a></li>

                            <li><a href="/Home/Properties">  Properties</a></li>
                            <li><a href="/Home/ContactUs"> Contact</a></li>
                            <li><a href="/Home/AreaAttractions">Area Attractions</a></li>
                            
                        </ul>
                    </aside>
                </div>
                <div className="col-md-3 col-xs-6">
                    <aside className="f_widget link_widget">
                        <div className="f_title">
                            <h3>Important Links</h3>
                        </div>
                        <ul>
                            <li><a href="/Home/Privacy">  Privacy Policy</a></li>
                            <li><a href="/Home/Policies">  Policies & Terms</a></li>
                           
                        
                            <li><a href="/Home/Cookies">  Cookie Notice</a></li>
                            <li><a href="/Home/Review">  Reviews & Testimonials</a></li>
                            <li><a href="/Home/MapDirections">  Map & Directions</a></li>






                        </ul>
                    </aside>
                </div>
                <div className="col-md-2 col-xs-3">
                    <aside className="f_widget instagram_widget">
                        <div className="f_title">
                            <h3>Social Links</h3>
                        </div>
                        <ul className="social-link">

                            <li><a href="https://www.facebook.com/MyOrlandoStay" target="_blank"><i className="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/MyOrlandoStay" target="_blank"><i className="fa fa-twitter"></i></a></li>
                            {/* @*<li><a href="https://www.tripadvisor.com/Rentals" target="_blank"><i className="fa fa-tripadvisor" aria-hidden="true"></i></a></li>*@
                            <li><a href="https://www.pinterest.com/MyOrlandoStay/" target="_blank"><i className="fa fa-pinterest-p" aria-hidden="true"></i></a></li>

                           @* <li>  <a href='https://www.free-counters.org/'>Get free Counters</a></li>*@   */}

                        </ul>
                    </aside>
                </div>
            </div>
        </div>
    </div>
    <div className="footer_copyright_area" style={{textAlign:"center", color:"#333"}}>
        <div className="container">
            <div className="">
                <h4  className="footer_copyright">
                    Copyright © Disney Area Vacation Rental by <a href="" className="home_link"> My Orlando Stay</a> , LLC
                    . All rights reserved.
                </h4>
            </div>
            {/* <!-- <div className="pull-right">
                <h4>Created by: <a href="#">DesignArc</a></h4>
            </div> --> */}
        </div>
    </div>
</footer></>
  )
}

export default Footer