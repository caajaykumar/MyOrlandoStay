
'use client';

import Image from 'next/image';
import React, { useState } from "react";
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import style from './unitdetails.module.css'
import Link from 'next/link';

const unitImages = [
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0023.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0006.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0013.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0015.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0016.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0019.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0020.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0021.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0023.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0024.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0025.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0026.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0029.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0030.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0032.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0033.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0035.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0037.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0039.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0040.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0042.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0044.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0047.jpg',
];

const galleryImages = [
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0023.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0006.jpg',

    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0013.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0015.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0016.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0019.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0020.jpg',

    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0021.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0023.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0024.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0025.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0026.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0029.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0030.jpg',
    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0032.jpg',

    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0033.jpg',

    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0035.jpg',

    'https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0037.jpg',
];


const amenities = [
    { name: 'Bath', icon: 'M7.5 2a4.5 4.5 0 0 1 4.47 4H14v2H8V6h1.95A2.5 2.5 0 0 0 5 6.34V16h26v2h-2v5a5 5 0 0 1-3 4.58V30h-2v-2H8v2H6v-2.42a5 5 0 0 1-3-4.34V18H1v-2h2V6.5A4.5 4.5 0 0 1 7.5 2zM27 18H5v5a3 3 0 0 0 2.65 2.98l.17.01L8 26h16a3 3 0 0 0 3-2.82V23z' },
    { name: 'Hair dryer', icon: 'M14 27v.2a4 4 0 0 1-3.8 3.8H4v-2h6.15a2 2 0 0 0 1.84-1.84L12 27zM10 1c.54 0 1.07.05 1.58.14l.38.07 17.45 3.65a2 2 0 0 1 1.58 1.79l.01.16v6.38a2 2 0 0 1-1.43 1.91l-.16.04-13.55 2.83 1.76 6.5A2 2 0 0 1 15.87 27l-.18.01h-3.93a2 2 0 0 1-1.88-1.32l-.05-.15-1.88-6.76A9 9 0 0 1 10 1zm5.7 24-1.8-6.62-1.81.38a9 9 0 0 1-1.67.23h-.33L11.76 25zM10 3a7 7 0 1 0 1.32 13.88l.33-.07L29 13.18V6.8L11.54 3.17A7.03 7.03 0 0 0 10 3zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z' },
    { name: 'Shampoo', icon: 'M20 1v2h-3v2h1a2 2 0 0 1 2 1.85V9a4 4 0 0 1 4 3.8V27a4 4 0 0 1-3.8 4H12a4 4 0 0 1-4-3.8V13a4 4 0 0 1 3.8-4h.2V7a2 2 0 0 1 1.85-2H15V3H8V1zm2 21H10v5a2 2 0 0 0 1.85 2H20a2 2 0 0 0 2-1.85V27zm0-6H10v4h12zm-2-5h-8a2 2 0 0 0-2 1.85V14h12v-1a2 2 0 0 0-2-2zm-2-4h-4v2h4z' },
    // You would add more amenities here, mapping Font Awesome classes to SVG paths or using a React icon library
    { name: 'Wardrobe/Closet', faClass: 'fa fa-archive' },
    { name: 'Tumble dryer', faClass: 'fa fa-asterisk' },
    { name: 'Kitchenware', faClass: 'fa fa-cutlery' },
    { name: 'Oven', faClass: 'fa fa-fire' },
    { name: 'Barbecue', faClass: 'fa fa-fire-extinguisher' },
    { name: 'Toaster', faClass: 'fa fa-square-o' },
    { name: 'Stovetop', faClass: 'fa fa-fire' },
    { name: 'Tile/Marble floor', faClass: 'fa fa-th' },
    { name: 'Private entrance', faClass: 'fa fa-lock' },
    { name: 'View', faClass: 'fa fa-eye' },
    { name: 'Electric kettle', faClass: 'fa fa-bolt' },
    { name: 'Dining area', faClass: 'fa fa-cutlery' },
    { name: 'Alarm clock', faClass: 'fa fa-clock-o' },
];

export default function UnitDetails({ params }) {
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [isAmenitiesModalOpen, setIsAmenitiesModalOpen] = useState(false);
    const [currentSlide, setCurrentSlide] = useState(0);

    const openPopup = () => setIsPopupOpen(true);
    const closePopup = () => setIsPopupOpen(false);

    const openAmenitiesModal = () => setIsAmenitiesModalOpen(true);
    const closeAmenitiesModal = () => setIsAmenitiesModalOpen(false);

    const moveSlide = (direction) => {
        setCurrentSlide((prevSlide) => {
            const newSlide = prevSlide + direction;
            if (newSlide < 0) return 0; // Prevent going below the first slide
            if (newSlide >= Math.ceil(4 / 2)) return prevSlide; // Assuming 2 cards visible, adjust as needed
            return newSlide;
        });
    };
    return (
        <>
            <section className="banner_area">
                <div className="container">
                    <div className="banner_inner_content">
                        <h1>Unit 2 Premier Three-Bedroom Home, Crestwynd</h1>
                        <ul>
                            <li className="active">
                                <Link href="/">
                                    Home
                                </Link>
                            </li>
                            <li>
                                <Link href="#">
                                    Unit 2 Premier Three-Bedroom Home, Crestwynd
                                </Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </section>
            {/*================End Banner Area =================*/}

            {/*================Search Room Area =================*/}
            <section className="room_details_area">
                <div className="container">
                    <div className="row room_details_inner">
                        <div className="col-md-6">
                            <div className="room_details_content">
                                <div className="room_d_main_text">
                                    <Swiper
                                        modules={[Navigation, Pagination, Autoplay]}
                                        navigation
                                        pagination={{ clickable: true }}
                                        autoplay={{ delay: 3000 }}
                                        loop
                                        spaceBetween={20}
                                    >
                                        {unitImages.map((src, index) => (
                                            <SwiperSlide key={index}>
                                                <Image
                                                    src={src}
                                                    alt={`Room ${index + 1}`}
                                                    width={800}
                                                    height={350}
                                                    className="img-fluid"
                                                    style={{ borderRadius: '8px' }}
                                                />
                                            </SwiperSlide>
                                        ))}
                                    </Swiper>

                                </div>
                            </div>
                        </div>




                        <div className="col-lg-3 col-md-3">
                            <Image
                                src="https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0035.jpg"
                                alt="Unit Image 1"
                                // className="img-responsive marbottomsm"
                                className={`img-responsive ${style.marbottomsm}`}
                                width={300}
                                height={200}
                                layout="responsive"
                            />
                            <Image
                                src="https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0039.jpg"
                                alt="Unit Image 2"
                                className={`img-responsive ${style.marbottomsm}`}
                                width={300}
                                height={200}
                                layout="responsive"
                            />
                        </div>

                        <div className="col-sm-3 col-md-3">
                            <Image
                                src="https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0042.jpg"
                                alt="Unit Image 3"
                                className={`img-responsive ${style.marbottomsm}`}
                                width={300}
                                height={200}
                                layout="responsive"
                            />
                            <Image
                                src="https://stssevastorage.blob.core.windows.net/myorlandostay/Unit2/IMG_0023.jpg"
                                alt="Unit Image 4"
                                className={`img-responsive ${style.marbottomsm}`}
                                width={300}
                                height={200}
                                layout="responsive"
                            />

                            <button className={`btn btn-info ${style.photobtn}`} id="openBtn" onClick={openPopup}>
                                <i className="fa fa-bars"></i> Show All Photos
                            </button>
                            {isPopupOpen && (
                                <>
                                    <div className={`${style.overlay} ${style.show}`} id="overlay" onClick={closePopup}></div>
                                    <div className={`${style.popup} ${style.show}`} id="popup">
                                        <button className={style.close_btn} onClick={closePopup}>X</button>
                                        <div className="photo-gallery content-area">
                                            <div className="container">
                                                <div className="main-title">
                                                    <h1>Unit 2 Photo Tour</h1>
                                                </div>
                                                <div className="filter-portfolio">
                                                    <div className="row">
                                                        {galleryImages.map((src, index) => (
                                                            <div className="col-lg-4 col-md-6 col-sm-12 filtr-item" key={index}>
                                                                <figure className="portofolio-thumb">
                                                                    <Link href="#">
                                                                        <Image src={src} alt="image" className="img-fluid w-100" width={400} height={300} layout="responsive" />
                                                                    </Link>
                                                                </figure>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>

                    <div className="row room_details_inner">
                        <div className="col-md-8">
                            <div className="room_details">
                                <h2 className="home_name"> Unit 2 Premier Three-Bedroom Home, Crestwynd</h2>

                                <ul className="home_feature">
                                    <li>. 8 guests</li>
                                    <li>. 3 bedrooms</li>
                                    <li>. 5 beds</li>
                                    <li>. 2.5 bathrooms</li>
                                </ul>
                            </div>

                            <div className="host_details">
                                <div className="item item_img">
                                    <Image
                                        src="/img/manny.png"
                                        alt="Manny"
                                        className="manny_img"
                                        width={50}
                                        height={50}
                                    />
                                </div>
                                <div className="item item_name">
                                    <p>Hosted by Manny</p>
                                    <span> 13 years hosting</span>
                                </div>
                            </div>

                            <div className="host_details">
                                <div className="item item_img">
                                    <Image
                                        src="/img/icon/check-in.png"
                                        alt="Check-in"
                                        width={24}
                                        height={24}
                                    />
                                </div>
                                <div className="item item_name">
                                    <p>Self check-in</p>
                                    <span>Check yourself in with the keypad.</span>
                                </div>
                            </div>

                            <div className="s_blog_quote1">
                                <div id="content">
                                    <div id="shortContent">
                                        Unit 2 is our premier three-bedroom home, thoughtfully decorated and set up by the owners of MyOrlandoStay.
                                        We bring to you comfort and convenience for a memorable stay.
                                        <ul className="room_facilities_list">
                                            <li>
                                                Bedrooms:
                                                <ul>
                                                    <li>1 KING bed with attached bathroom</li>
                                                    <li>1 QUEEN bedroom with attached bath</li>
                                                    <li>1 Kids bedroom with 2 twin beds</li>
                                                </ul>
                                            </li>
                                            <li>
                                                Capacity:
                                                <ul>
                                                    <li>In-home laundry (washer and dryer)</li>
                                                    <li>Sleeper sofa and one bedroom downstairs</li>
                                                </ul>
                                            </li>
                                            <li>
                                                Amenities:
                                                <ul>
                                                    <li>Close proximity to the pool</li>
                                                    <li>Cable and flat-screen TVs</li>
                                                    <li>Complimentary WIFI and high-speed internet</li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div className="bed_details">
                                <h3>Where you'll sleep</h3>
                                <div className="slider">
                                    <button className="prev" onClick={() => moveSlide(-1)}>&#10094;</button>
                                    <div className="cards-container" style={{ transform: `translateX(-${currentSlide * 50}%)` }}> {/* Adjust 50% based on card width and number of visible cards */}
                                        <div className="cards">
                                            <div className="card">
                                                <Image src="/img/icon/bedroom.png" alt="Bedroom icon" className="bed_img" width={50} height={50} />
                                                <h3>Bedroom 1</h3>
                                                <p>1 king bed</p>
                                            </div>
                                            <div className="card">
                                                <Image src="/img/icon/bedroom.png" alt="Bedroom icon" className="bed_img" width={50} height={50} />
                                                <h3>Bedroom 2</h3>
                                                <p>1 king bed</p>
                                            </div>
                                            <div className="card">
                                                <Image src="/img/icon/twinbed.png" alt="Twin bed icon" className="bed_img" width={50} height={50} />
                                                <h3>Bedroom 3</h3>
                                                <p>1 single bed, 1 bunk bed</p>
                                            </div>
                                            <div className="card">
                                                <Image src="/img/icon/beds.png" alt="Beds icon" className="bed_img" width={50} height={50} />
                                                <h3>Common spaces</h3>
                                                <p>1 single bed</p>
                                            </div>
                                        </div>
                                    </div>
                                    <button className="next" onClick={() => moveSlide(1)}>&#10095;</button>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4">
                            <div className="search_right_sidebar">
                                <div className="book_room_area">
                                    <div className="book_room_box">
                                        <div className="book_table_item">
                                            <h3>check availability</h3>
                                        </div>
                                        <div className="book_table_item">
                                            <div className="input-append date form_datetime">
                                                <input size="16" type="text" readOnly placeholder="Arrival Date" />
                                                <span className="add-on"><i className="fa fa-calendar" aria-hidden="true"></i></span>
                                            </div>
                                        </div>
                                        <div className="book_table_item">
                                            <div className="input-append date form_datetime">
                                                <input size="16" type="text" readOnly placeholder="Departure Date" />
                                                <span className="add-on"><i className="fa fa-calendar" aria-hidden="true"></i></span>
                                            </div>
                                        </div>
                                        <div className="book_table_item">
                                            <select className="form-control" tabIndex="-98">
                                                <option> Select Adults</option>
                                                <option> 1</option>
                                                <option> 2</option>
                                                <option> 3</option>
                                                <option> 4</option>
                                                <option> 5</option>
                                                <option> 6</option>
                                                <option> 7</option>
                                                <option> 8</option>
                                            </select>
                                        </div>
                                        <div className="book_table_item">
                                            <select className="form-control" tabIndex="-98">
                                                <option> Select Child</option>
                                                <option> 1</option>
                                                <option> 2</option>
                                                <option> 3</option>
                                                <option> 4</option>
                                                <option> 5</option>
                                                <option> 6</option>
                                                <option> 7</option>
                                                <option> 8</option>
                                            </select>
                                        </div>
                                        <div className="book_table_item">
                                            <select className="form-control" tabIndex="-98">
                                                <option> Select Pets </option>
                                                <option> Yes</option>
                                                <option> No</option>
                                            </select>
                                        </div>
                                        <div className="book_table_item">
                                            <a className="book_now_btn" href="https://www.lodgix.com/booking-calendar/websites/25634/properties/62271/">
                                                Reserve now
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="row room_details_inner" style={{ borderBottom: '1px solid #ccc' }}>
                        <div className="amenities col-md-12">
                            <h3 style={{ marginBottom: '10px' }}> What this place offers </h3>
                            <div className="row">
                                <div className="col-md-3">
                                    <ul className={style.amenities_list}>
                                        <li><i className="fa fa-archive"></i> Wardrobe/Closet</li>
                                        <li><i className="fa fa-asterisk"></i> Tumble dryer</li>
                                        <li><i className="fa fa-cutlery"></i> Kitchenware</li>
                                        <li><i className="fa fa-fire"></i> Oven</li>
                                        <li><i className="fa fa-fire-extinguisher"></i> Barbecue</li>
                                        <li><i className="fa fa-square-o"></i> Toaster</li>
                                        <li><i className="fa fa-fire"></i> Stovetop</li>
                                    </ul>
                                </div>
                                <div className="col-md-3">
                                    <ul className={style.amenities_list}>
                                        <li><i className="fa fa-th"></i> Tile/Marble floor</li>
                                        <li><i className="fa fa-lock"></i> Private entrance</li>
                                        <li><i className="fa fa-eye"></i> View</li>
                                        <li><i className="fa fa-bolt"></i> Electric kettle</li>
                                        <li><i className="fa fa-cutlery"></i> Dining area</li>
                                        <li><i className="fa fa-clock-o"></i> Alarm clock</li>
                                    </ul>
                                </div>
                                <div className="col-md-12">
                                    <button id="openModalBtn" className={style.button1} onClick={openAmenitiesModal}> Show All Amenities </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div className="row room_details_inner" style={{ borderBottom: '1px solid #ccc' }}>
                        <div className="calender">
                            <div className="col-md-12">
                                <h3 style={{ marginBottom: '10px', marginTop: '20px' }}> Booking Calendar </h3>
                                <iframe
                                    src="https://www.lodgix.com/booking-calendar/websites/25634/properties/62271/"
                                    style={{ width: '100%', height: '650px', border: 'none' }}
                                    id="lodgix-calendar-iframe"
                                ></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Photo gallery popup */}
            {isPopupOpen && (
                <div className={style.popup} id="popup">
                    <button className={style.close_btn} onClick={closePopup}>X</button>
                    <div className="photo-gallery content-area">
                        <div className="container">
                            <div className="main-title">
                                <h1>Unit 2 Photo tour</h1>
                            </div>
                            <div className="filter-portfolio">
                                <div className="row">
                                    {galleryImages.map((src, index) => (
                                        <div className="col-lg-4 col-md-6 col-sm-12 filtr-item" key={index}>
                                            <figure className={style.portofolio_thumb}>
                                                <Link href="#">
                                                    <Image src={src} alt="image" className={`img-fluid w-100 ${style.img_pb}`} width={400} height={300} layout="responsive" />
                                                </Link>
                                            </figure>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Amenities Modal */}
            {isAmenitiesModalOpen && (
                <div id="myModal" className={style.modal} style={{ display: 'flex' }}>
                    <div className={style.modal_content}>
                        <div className={style.modal_header}>
                               {/* <button className={style.close_btn} onClick={closePopup}>X</button>
                              */}

                           <button className={style.close_btn} onClick={closeAmenitiesModal}> X</button> 
                        </div>
                        <h2 className={style.aminites_pop_main_Heading}> What this place offers</h2>
                        <h4 className={style.amimites_category}> Bathroom</h4>
                        <ul className={style.aminities_list}>
                            {amenities.filter(a => ['Bath', 'Hair dryer', 'Shampoo'].includes(a.name)).map((amenity, index) => (
                                <li key={index}>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true" role="presentation" focusable="false" style={{ display: 'block', height: '24px', width: '24px', fill: 'currentcolor' }}>
                                        <path d={amenity.icon}></path>
                                    </svg> {amenity.name}
                                </li>
                            ))}
                        </ul>
                        <h4 className={style.amimites_category}> Kitchen</h4>
                        <ul className={style.aminities_list}>
                            {amenities.filter(a => ['Wardrobe/Closet', 'Tumble dryer', 'Kitchenware', 'Oven', 'Barbecue', 'Toaster', 'Stovetop'].includes(a.name)).map((amenity, index) => (
                                <li key={index}>
                                    {amenity.faClass ? <i className={amenity.faClass}></i> : null} {amenity.name}
                                </li>
                            ))}
                        </ul>
                        <h4 className={style.amimites_category}> General</h4>
                        <ul className={style.aminities_list}>
                            {amenities.filter(a => ['Tile/Marble floor', 'Private entrance', 'View', 'Electric kettle', 'Dining area', 'Alarm clock'].includes(a.name)).map((amenity, index) => (
                                <li key={index}>
                                    {amenity.faClass ? <i className={amenity.faClass}></i> : null} {amenity.name}
                                </li>
                            ))}
                        </ul>
                        {/* You would dynamically generate categories and lists for all amenities */}
                    </div>
                </div>
            )}
        </>
    );
}
