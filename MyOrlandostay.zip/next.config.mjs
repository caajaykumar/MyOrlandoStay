/** @type {import('next').NextConfig} */
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: [
      'stssevastorage.blob.core.windows.net',
      
    ],
  },
};

export default nextConfig;

